Description
-----------
This module adds a KISSinsights box to your web site.

Installation
------------
To install copy the kissinsights folder to your modules folder.


Configuration
-------------
Enable this module, visit Administer -> Site building -> Modules, and enable kissinsights.

For this module to work, you need to create a survey at www.kissinsights.com.

To configure it, go to Administer -> Site configuration -> KISSinsights

Fill out the needed fields.

When proper installed and configured, you will have a KISSinsights box shown at your website.

Bugs/Features/Patches
---------------------
If you want to report bugs, feature requests, or submit a patch, please do
so at the project page on the Drupal web site.
http://drupal.org/project/kissinsights

Author
------
Hasse Ramlev Hansen (http://ramlev.dk)

Todo
----
* Black-/whitelist pages.
