A few notes and TODOS:
for photo and thumbnail url change the display formatter to "gigya profile2 image display". TODO: find out how to set this when creating an instance.
the field formatter is not the best implementation but for now.
once you created a profile type you can only add the extra fields  by hand.


