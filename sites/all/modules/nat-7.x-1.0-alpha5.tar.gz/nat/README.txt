
The NAT module is a helper module used to maintain node-term relationships,  
i.e. when a node is created a taxonomy term is created automatically using its 
title and body in any associated vocabularies. This module also attempts to 
preserve hierarchical relationships where possible.

Project URL: http://drupal.org/node/59096
